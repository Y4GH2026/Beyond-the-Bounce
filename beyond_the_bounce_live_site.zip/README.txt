HOW TO MAKE THIS LIVE

Fastest option: Netlify Drop
1. Go to https://app.netlify.com/drop
2. Drag and drop this entire folder OR the ZIP file.
3. Netlify will give you a public live website link.
4. Share that link or make a QR code from it.

This is a mobile-friendly web app. Guests can open it on their phones.
